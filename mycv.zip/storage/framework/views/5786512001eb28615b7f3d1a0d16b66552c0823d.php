

<?php $__env->startSection("title"); ?>
Languages
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

<form  id="create_form" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?> 
    <div class="form-group">
      <label for="name">Name</label>
      <input type="text" class="form-control" id="name"  name="name" aria-describedby="emailHelp" placeholder="Enter Language Name">
      <small id="name_error" class="form-text text-danger" style="display: none"></small>
    </div>
    <div class="form-group">
        <label for="description">Description</label>
        <input type="text" class="form-control" id="description"  name="description" aria-describedby="emailHelp" placeholder="Enter Language Description">
        <small id="description_error" class="form-text text-danger" style="display: none"></small>
      </div>
      <button type="submit" class="btn btn-primary">Save</button>
      <small id="success_msg" class="alert alert-success" style="display: none"></small>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("scripts"); ?>

<script>
    $(document).on('click', '#create_form', function (e) {
        e.preventDefault();
        $('small').text("");
        $('small').css("display:none");
        var formData = new FormData($('#create_form')[0]);
        $.ajax({
            type: 'post',
            enctype: 'multipart/form-data',
            url: "<?php echo e(route('language.save')); ?>",
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function (data) {
                if(data.status == true){
                    $('#success_msg').text("Created Successfully...");
                    $('#success_msg').show();
                }
            }, error: function (reject) {
                var response = $.parseJSON(reject.responseText);
                $.each(response.errors, function (key, val) {
                $("#" + key + "_error").text(val[0]);
                $("#" + key + "_error").show();
            });
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/907/18746907/resources/views/admin/createLanguage.blade.php ENDPATH**/ ?>