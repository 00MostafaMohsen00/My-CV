<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My CV</title>

         <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> 
<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.no-icons.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset("font-awesome/css/font-awesome.css")); ?>">

</head>
<body >
<div class="parent">
    <div class="container container-fluid">
        <div class="card mb-3">
            <div class="row g-0 row-one">
                <div class="col-md-4 col-sm-3" >
                   <img class="image" src="<?php echo e($user->image); ?>"   alt="My picture">
                </div>
                <div class="col-md-8 col-sm-6">
                    <div class="card-body content">
                        <h1 class="card-title"><?php echo e($user->name); ?></h1><hr>
                        <div class="row g-0">
                            <div class="col-6 col-md-8 col-sm-8 col-lg-6 w-25 personal">
                                <fieldset>
                                    <legend>Personal Information</legend>
                                    <ul>
                                        <li> Nationality : <?php echo e($user->personals->nationality); ?></li>
                                        <li> Address : <?php echo e($user->personals->address); ?></li>
                                        <li> Date of birth : <?php echo e($user->personals->date_of_birth); ?></li>
                                        <li> Education : <?php echo e($user->personals->education); ?></li>
                                        <li> Job : <?php echo e($user->personals->job); ?></li>
                                        <li> Military Status : <?php echo e($user->personals->Military_service); ?></li>
                                    </ul>
                                </fieldset>
                            </div>
                            <div class="col-6 col-md-8 col-sm-8 col-lg-6 w-25 skills">
                                <fieldset>
                                    <legend>Skills</legend>
                                    <ol>
                                        <?php $__currentLoopData = $user->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skills): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li> <?php echo e($skills->name); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                </fieldset>
                            </div>
                        </div> 
                        <div class="row g-0">
                            <div class="col-6 col-md-4 col-sm-4 col-lg-6 w-25 contact" >
                                <fieldset >
                                    <legend >Contact Information</legend>
                                    <ul>
                                        <?php $__currentLoopData = $user->contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($contacts->link); ?>"><i class="<?php echo e($contacts->icon); ?>"> <?php echo e($contacts->name); ?></i></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </fieldset>
                            </div>
                            <div class="col-6 col-md-4 col-sm-4 col-lg-6 w-25 languages" >
                                <fieldset>
                                    <legend >Languages</legend>
                                    <ul>
                                        <?php $__currentLoopData = $user->languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $languages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($languages->name); ?> : <?php echo e($languages->description); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </fieldset>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-12 col-md-6 col-sm-5 col-lg-12 w-25 summary">
                                <fieldset>
                                    <legend>Summary</legend>
                                    <p> <?php echo e($user->summary->title); ?></p>
                                </fieldset>
                          </div>
                    </div>
                </div>
            </div>
     
        </div>
    </div>
</div>
<link rel="stylesheet" href="<?php echo e(asset("css/main.css")); ?>">
</body>
</html><?php /**PATH /storage/ssd3/907/18746907/resources/views/home.blade.php ENDPATH**/ ?>