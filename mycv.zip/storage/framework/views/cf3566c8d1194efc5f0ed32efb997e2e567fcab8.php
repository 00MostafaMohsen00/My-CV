


<?php $__env->startSection("title"); ?>
Skills
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

<a href="<?php echo e(route("skill.create")); ?>" class="btn btn-success">Create</a>
<div>

    <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Operations</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
                <tr id="<?php echo e($skill->id); ?>">
                        <th scope="row" ><?php echo e($skill->id); ?></th>
                        <td><?php echo e($skill->name); ?></td>
                        <td>
                            <button  class="btn btn-primary"><a href="<?php echo e(route("skill.update",$skill->id)); ?>" class="btn btn-primary">Update</a></button>
                           <button id="<?php echo e($skill->id); ?>" class="delete_button btn btn-danger"> <a  class="btn btn-danger">Delete</a></button>
                        </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        </tbody>
      </table>

</div>
<small id="success_msg" class="alert alert-success" style="display: none"></small>
<small id="error_msg" class="alert alert-success" style="display: none"></small>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("scripts"); ?>
<script>
    $(document).on('click', '.delete_button', function (e) {
        e.preventDefault();
        $('small').text("");
        $('small').css("display:none");
        var skill_id =  $(this).attr('id');
        $.ajax({
            type: 'post',
             url: "<?php echo e(route('skill.delete')); ?>",
             data: {
                    '_token': "<?php echo e(csrf_token()); ?>",
                    'id' :skill_id
                },
            success: function (data) {
                if(data.status == true){
                    e.preventDefault();
                    $('#success_msg').text("Deleted Successfully...");
                    $('#success_msg').show();
                    $('#'+skill_id).remove();
                }
            }, error: function (reject) {
                var response = $.parseJSON(reject.responseText);
                $.each(response.errors, function (key, val) {
                $("#error_msg").text(val[0]);
                $("#error_msg").show();
        });
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/907/18746907/resources/views/admin/skills.blade.php ENDPATH**/ ?>