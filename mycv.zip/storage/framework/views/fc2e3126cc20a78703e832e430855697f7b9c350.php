
<?php $__env->startSection("title"); ?>
Summary
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<form method="POST" id="summary_form">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <div><label for="title" class="h1">Summary</label></div><hr>
      <div><textarea name="title" class="form-controller"  cols="30" rows="10" placeholder="write here what you want"><?php echo e($summary[0]->title); ?></textarea></div>
      <button type="submit" class="justify-content-center btn btn-primary">Update</button>
    </div>
  </form>
  <small class="alert alert-success" id="success_msg" style="display: none"></small>
<small id="title_error" class="form-text text-danger" style="display: none"></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("scripts"); ?>
<script>
    $(document).on('click', '#summary_form', function (e) {
        e.preventDefault();
        $('#title_error').text(" ");
        $('#title_error').css("display:none");
        $("#success_msg").text(" ");
        $("#success_msg").css("display:none");
        var formData = new FormData($('#summary_form')[0]);
        $.ajax({
            type: 'post',
            enctype: 'multipart/form-data',
            url: "<?php echo e(route('edit.summary')); ?>",
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function (data) {
                if(data.status == true){
                    $('#success_msg').text("Updated Successfully...");
                    $('#success_msg').show();
                }
            }, error: function (reject) {
                var response = $.parseJSON(reject.responseText);
                $.each(response.errors, function (key, val) {
                $("#" + key + "_error").text(val[0]);
                $("#" + key + "_error").show();
            });
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mycv\resources\views/admin/summary.blade.php ENDPATH**/ ?>