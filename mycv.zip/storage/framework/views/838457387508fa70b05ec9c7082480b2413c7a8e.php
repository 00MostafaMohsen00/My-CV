

<?php $__env->startSection("title"); ?>
Contacts
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>

<a href="<?php echo e(route("contact.create")); ?>" class="btn btn-success">Create</a>
<div>

    <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Icon</th>
            <th scope="col">Link</th>
            <th scope="col">Operations</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
                <tr id="<?php echo e($contact->id); ?>">
                        <th scope="row" ><?php echo e($contact->id); ?></th>
                        <td><?php echo e($contact->name); ?></td>
                        <td><i class="<?php echo e($contact->icon); ?>"></i></td>
                        <td><?php echo e($contact->link); ?></td>
                        <td>
                           <button  class="btn btn-primary"><a href="<?php echo e(route('contact.update',$contact->id)); ?>" class="btn btn-primary">Update</a></button>
                           <button id="<?php echo e($contact->id); ?>" class="delete_button btn btn-danger"> <a  class="btn btn-danger">Delete</a></button>
                        </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        </tbody>
      </table>

</div>
<small id="success_msg" class="alert alert-success" style="display: none"></small>
<small id="error_msg" class="alert alert-success" style="display: none"></small>



<?php $__env->stopSection(); ?>


<?php $__env->startSection("scripts"); ?>
<script>
    $(document).on('click', '.delete_button', function (e) {
        e.preventDefault();
        $('small').text("");
        $('small').css("display:none");
        var contact_id =  $(this).attr('id');
        $.ajax({
            type: 'post',
             url: "<?php echo e(route('contact.delete')); ?>",
             data: {
                    '_token': "<?php echo e(csrf_token()); ?>",
                    'id' :contact_id
                },
            success: function (data) {
                if(data.status == true){
                    e.preventDefault();
                    $('#success_msg').text("Deleted Successfully...");
                    $('#success_msg').show();
                    $('#'+contact_id).remove();
                }
            }, error: function (reject) {
                var response = $.parseJSON(reject.responseText);
                $.each(response.errors, function (key, val) {
                $("#error_msg").text(val[0]);
                $("#error_msg").show();
        });
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mycv\resources\views/admin/contacts.blade.php ENDPATH**/ ?>