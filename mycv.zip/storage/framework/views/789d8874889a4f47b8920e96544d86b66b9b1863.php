
<?php $__env->startSection("title"); ?>
Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<form  id="personal_form" method="POST" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="form-group">
    <img src="<?php echo e($user->image); ?>" alt="My photo">
    <input type="file" class="form-control" id="image"  name="image" aria-describedby="emailHelp" placeholder="Upload Image">
  </div>
  <div class="form-group">
    <label for="name">Name</label>
    <input type="text" class="form-control" id="address" value="<?php echo e($user->name); ?>" name="name" aria-describedby="emailHelp" placeholder="Enter your Name">
    <small id="name_error" class="form-text text-danger" style="display: none"></small>
  </div>
    <div class="form-group">
      <label for="address">Address</label>
      <input type="text" class="form-control" id="address" value="<?php echo e($personal[0]->address); ?>" name="address" aria-describedby="emailHelp" placeholder="Enter your address">
      <small id="address_error" class="form-text text-danger" style="display: none"></small>
    </div>
    <div class="form-group">
      <label for="education">Education</label>
      <input type="text" class="form-control" id="education" placeholder="Enter your Education" name="education" value="<?php echo e($personal[0]->address); ?>">
    </div>
    <div class="form-group">
        <label for="address">Job</label>
        <input type="text" class="form-control" id="job" value="<?php echo e($personal[0]->job); ?>" name="job" aria-describedby="emailHelp" placeholder="Enter your job">
        <small id="job_error" class="form-text text-danger" style="display: none"></small>
      </div>
      <div class="form-group">
        <label for="address">Nationality</label>
        <input type="text" class="form-control" id="nationality" value="<?php echo e($personal[0]->nationality); ?>" name="nationality" aria-describedby="emailHelp" placeholder="Enter your nationality">
        <small id="nationality_error" class="form-text text-danger" style="display: none"></small>
      </div>
      <div class="form-group">
        <label for="address">Date Of Birth</label>
        <input type="date" class="form-control" id="date_of_birth" value="<?php echo e($personal[0]->date_of_birth); ?>" name="date_of_birth" aria-describedby="emailHelp" placeholder="Enter your Date Of Birth">
        <small id="date_of_birth_error" class="form-text text-danger" style="display: none"></small>
      </div>
      <div class="form-group">
        <label for="address">Military Service</label>
        <input type="text" class="form-control" id="military_service" value="<?php echo e($personal[0]->Military_service); ?>" name="Military_service" aria-describedby="emailHelp" placeholder="Enter your Military service">
        <small id="Military_service_error" class="form-text text-danger" style="display: none"></small>
      </div>
    <button type="button" class="submit-button btn btn-primary">Update</button>
    <small id="success_msg" class="alert alert-success" style="display: none"></small>
  </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("scripts"); ?>
<script>
    $(document).on('click', '.submit-button', function (e) {
        $('small').text(" ");
        $('small').css("display:none");
        var formData = new FormData($('#personal_form')[0]);
        $.ajax({
            type: 'post',
            enctype: 'multipart/form-data',
            url: "<?php echo e(route('personal.save')); ?>",
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function (data) {
                if(data.status == true){
                    $('#success_msg').text("Updated Successfully...");
                    $('#success_msg').show();
                    $('img').src="<?php echo e($user->image); ?>";
                }
            }, error: function (reject) {
                var response = $.parseJSON(reject.responseText);
                $.each(response.errors, function (key, val) {
                $("#" + key + "_error").text(val[0]);
                $("#" + key + "_error").show();
            });
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/907/18746907/resources/views/admin/index.blade.php ENDPATH**/ ?>